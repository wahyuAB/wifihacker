# wifi-hack
Perma kalinya
